﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using DAL;
using BLL;
using System.Data.SqlClient;
using System.Threading;
using System.IO.Ports;

namespace RFIDBIG
{
    public partial class Storage : UserControl
    {

        UserBLL userbll = new UserBLL();
        List<User> users = new List<User>();
        User usr = new User();     

        public Storage()
        {
            InitializeComponent();
        }



        //添加界面
        private void Btn_TJ_Click_1(object sender, EventArgs e)
        {
            TianJia TJ = new TianJia();
            splitContainer2.Panel2.Controls.Clear();
            splitContainer2.Panel2.Controls.Add(TJ);
            TJ.myrefresh += new TianJia.refresh(refresh);
            

        }

        private void Storage_Load(object sender, EventArgs e)
        {
            List<User> users = userbll.SearchAllUsers();
            dataGridView.DataSource = users;
            //DataGridView默认指向第一行
            usr.PortID = Convert.ToInt32(dataGridView.Rows[0].Cells[0].Value);
            usr.Name = dataGridView.Rows[0].Cells[1].Value.ToString();
            usr.Money = Convert.ToSingle(dataGridView.Rows[0].Cells[2].Value);

            

        }

        public void re()
        {
            List<User> users = userbll.SearchAllUsers();
            dataGridView.DataSource = users;
            usr.PortID = Convert.ToInt32(dataGridView.Rows[0].Cells[0].Value);
            usr.Name = dataGridView.Rows[0].Cells[1].Value.ToString();
            usr.Money = Convert.ToSingle(dataGridView.Rows[0].Cells[2].Value);
        }

        private void refresh()
        {
            re();
        }

        private void Btn_Xiu_Click(object sender, EventArgs e)
        {
            XuiGai XG = new XuiGai();
            splitContainer2.Panel2.Controls.Clear();
            splitContainer2.Panel2.Controls.Add(XG);
            XG.myrefresh += new XuiGai.refresh(refresh);
        }





    }
}
