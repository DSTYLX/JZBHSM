﻿namespace RFIDBIG
{
    partial class ChargeAndBusiness
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TB_Name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnStartCreateCard = new System.Windows.Forms.Button();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtCardID = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnACharge = new System.Windows.Forms.Button();
            this.txtAChargeAmount = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.TB_M = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TB_Name);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnStartCreateCard);
            this.groupBox1.Controls.Add(this.txtAmount);
            this.groupBox1.Controls.Add(this.txtCardID);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(349, 433);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "制卡";
            // 
            // TB_Name
            // 
            this.TB_Name.Location = new System.Drawing.Point(82, 92);
            this.TB_Name.Name = "TB_Name";
            this.TB_Name.Size = new System.Drawing.Size(220, 21);
            this.TB_Name.TabIndex = 28;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 27;
            this.label1.Text = "用户名：";
            // 
            // btnStartCreateCard
            // 
            this.btnStartCreateCard.Location = new System.Drawing.Point(104, 251);
            this.btnStartCreateCard.Name = "btnStartCreateCard";
            this.btnStartCreateCard.Size = new System.Drawing.Size(75, 23);
            this.btnStartCreateCard.TabIndex = 26;
            this.btnStartCreateCard.Text = "制卡";
            this.btnStartCreateCard.UseVisualStyleBackColor = true;
            this.btnStartCreateCard.Click += new System.EventHandler(this.btnStartCreateCard_Click);
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(82, 155);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(220, 21);
            this.txtAmount.TabIndex = 22;
            // 
            // txtCardID
            // 
            this.txtCardID.Location = new System.Drawing.Point(82, 39);
            this.txtCardID.Name = "txtCardID";
            this.txtCardID.Size = new System.Drawing.Size(220, 21);
            this.txtCardID.TabIndex = 20;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 158);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 18;
            this.label15.Text = "金额：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 48);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 12);
            this.label19.TabIndex = 16;
            this.label19.Text = "标签号：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.TB_M);
            this.groupBox2.Controls.Add(this.TB);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnACharge);
            this.groupBox2.Controls.Add(this.txtAChargeAmount);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Location = new System.Drawing.Point(358, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(349, 433);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "充值";
            // 
            // TB
            // 
            this.TB.Location = new System.Drawing.Point(84, 92);
            this.TB.Name = "TB";
            this.TB.Size = new System.Drawing.Size(167, 21);
            this.TB.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 23;
            this.label2.Text = "金额：";
            // 
            // btnACharge
            // 
            this.btnACharge.Location = new System.Drawing.Point(120, 251);
            this.btnACharge.Name = "btnACharge";
            this.btnACharge.Size = new System.Drawing.Size(75, 23);
            this.btnACharge.TabIndex = 12;
            this.btnACharge.Text = "充值";
            this.btnACharge.UseVisualStyleBackColor = true;
            this.btnACharge.Click += new System.EventHandler(this.btnACharge_Click);
            // 
            // txtAChargeAmount
            // 
            this.txtAChargeAmount.Location = new System.Drawing.Point(84, 155);
            this.txtAChargeAmount.Name = "txtAChargeAmount";
            this.txtAChargeAmount.Size = new System.Drawing.Size(167, 21);
            this.txtAChargeAmount.TabIndex = 10;
            this.txtAChargeAmount.TextChanged += new System.EventHandler(this.txtAChargeAmount_TextChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(22, 158);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 12);
            this.label23.TabIndex = 9;
            this.label23.Text = "充值金额：";
            // 
            // TB_M
            // 
            this.TB_M.Location = new System.Drawing.Point(84, 48);
            this.TB_M.Name = "TB_M";
            this.TB_M.Size = new System.Drawing.Size(167, 21);
            this.TB_M.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 26;
            this.label3.Text = "标签号：";
            // 
            // ChargeAndBusiness
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "ChargeAndBusiness";
            this.Size = new System.Drawing.Size(712, 439);
            this.Load += new System.EventHandler(this.ChargeAndBusiness_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox TB_Name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnStartCreateCard;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.TextBox txtCardID;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnACharge;
        private System.Windows.Forms.TextBox txtAChargeAmount;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox TB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_M;

    }
}
