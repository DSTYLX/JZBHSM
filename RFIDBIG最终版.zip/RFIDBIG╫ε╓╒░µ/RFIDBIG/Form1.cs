﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Model;
using DAL;
using BLL;
using System.Data.SqlClient;
using System.IO.Ports;
using System.Threading;
using IES_ISO14443_Share;


namespace RFIDBIG
{
    public partial class Form1 : Form
    {
        UserBLL userbll = new UserBLL();
        List<User> users = new List<User>();
        User usr = new User();

        int PortID;
        float money;

        private Thread thread_125k;
        private Thread thread_144443;
        bool IsOpen_125K;
        bool IsOpen_14443;
        SerialPort SerialPort;
        byte[] rcvdata = new byte[5];
        private string cardID;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            Control.CheckForIllegalCrossThreadCalls = false;
            string[] portID = SerialPort.GetPortNames();
            if (portID.Length < 0)
            {
                MessageBox.Show("没有找到系统窗口！");
            }
            else
            {
                CB_Shop_PortID.Items.AddRange(portID);
                CB_Shop_PortID.SelectedIndex = 0;
                CB_Z_PortID.Items.AddRange(portID);
                CB_Z_PortID.SelectedIndex = 0;
            }
            TB_Shop_Baud.Text = "9600";
            TB_Z_Baud.Text = "9600";



            //入库界面
            Storage sto = new Storage();
            TP_RK.Controls.Clear();
            TP_RK.Controls.Add(sto);
            

        }

        //打开商品串口
        private void Btn_Open_Click(object sender, EventArgs e)
        {
            if (Btn_Open.Text == "打开串口")
            {
                if (CB_Shop_PortID.SelectedIndex < 0)
                {
                    MessageBox.Show("请选择串口");
                }
                else
                {
                    try
                    {
                        SerialPort = new SerialPort(CB_Shop_PortID.Text);
                        SerialPort.DataBits = 8;
                        SerialPort.StopBits = StopBits.One;
                        SerialPort.Parity = Parity.None;
                        SerialPort.Open();
                        if (SerialPort.IsOpen)
                        {
                            Btn_Open.Text = "关闭串口";
                            IsOpen_125K = true;
                            MessageBox.Show("串口打开成功");
                            thread_125k = new Thread(ReceiveData);
                            thread_125k.IsBackground = true;
                            thread_125k.Start();




                        }
                    }
                    catch
                    {
                        MessageBox.Show("串口打开失败");
                    }

                }
            }
            else
            {
                if (IsOpen_125K)
                {
                    SerialPort.Close();
                    Btn_Open.Text = "打开串口";
                    IsOpen_125K = false;
                    MessageBox.Show("串口关闭");

                    money = 0;
                    
                }
                else
                {
                    MessageBox.Show("串口已关闭");
                }
            }
        }

        //韦根数据转换
        private void ReceiveData()
        {


            if (IsOpen_125K)
            {
                IsOpen_125K = true;
                while (IsOpen_125K)
                {

                    try
                    {


                        if (SerialPort.BytesToRead > 4)
                        {
                            int count = SerialPort.Read(rcvdata, 0, 5);

                            if (count == 5)
                            {
                                string time = System.DateTime.Now.ToLongTimeString();
                                string str = " ";
                                foreach (byte value in rcvdata)
                                {
                                    str += string.Format("{0:X2} ", value);
                                }

                                string strWGData = string.Format("{0:D3}{1:D5}", rcvdata[1], rcvdata[2] * 256 + rcvdata[3]);
                                PortID = Convert.ToInt32(strWGData);
                                LB_Money.Items.Add(strWGData);

                                //按ID查找
                                usr = userbll.SearchPortID(PortID);
                                PortID = usr.PortID;
                                LB_DD.Items.Add(usr.Name + usr.Money);


                                money += usr.Money;
                                //显示金额
                                ZE.Clear();
                                ZE.Text = Convert.ToString(money);

                                Int32 sum = rcvdata[0] + rcvdata[1] + rcvdata[2] + rcvdata[3] + rcvdata[4];
                                if (sum == 0)
                                {
                                    MessageBox.Show("接收到的数据全是0，请检查设备连接!");
                                }
                                else
                                {
                                    Thread.Sleep(20);
                                }
                            }
                            else
                            {
                                Thread.Sleep(20);
                            }



                        }
                        else
                        {
                            Thread.Sleep(20);
                        }
                    }
                    catch
                    {
                        IsOpen_125K = false;
                        MessageBox.Show("数据接收错误");
                        break;
                    }

                }
            }
            else
            {
                IsOpen_125K = false;
                SerialPort.Close();
                MessageBox.Show("串口关闭");
                Btn_Open.Text = "打开串口";
            }
        }


        //消费
        private void Btn_Con_Click(object sender, EventArgs e)
        {

            int[] a=new int[LB_Money.Items.Count];
            for(int i=0;i<LB_Money.Items.Count;i++)
            {
                usr.PortID=Convert.ToInt32(LB_Money.Items[i]);
                userbll.DeletePortID(usr.PortID);



            }
            LB_DD.Items.Clear();
            TB_X.Text = ZE.Text.Trim();
            ZE.Clear();

            IsOpen_125K = false;
            SerialPort.Close();
            Btn_Open.Text = "打开串口";
            money = 0;

        }

        //打开支付串口
        private void Btn_Z_Open_Click(object sender, EventArgs e)
        {
            if (Btn_Z_Open.Text == "打开串口")
            {

                if (!ISO14443_Tag.Is_Port)
                {
                    try
                    {
                        if (ISO14443_Tag.OpenPorts(CB_Z_PortID.Text) == "")
                        {
                            Btn_Z_Open.Text = "关闭串口";
                            ISO14443_Tag.Is_Port = true;
                            IsOpen_14443 = true;
                            MessageBox.Show("打开成功!");
                            thread_144443 = new Thread(Read);
                            thread_144443.IsBackground = true;
                            thread_144443.Start();



                        }

                    }
                    catch (Exception er)
                    {
                        MessageBox.Show(er.Message);
                    }
                }
            }
            else
            {
                if (IsOpen_14443)
                {
                    ISO14443_Tag.ClosePorts();
                    ISO14443_Tag.Is_Port = false;
                    IsOpen_14443 = false;
                    Btn_Z_Open.Text = "打开串口";
                }
 
            }

        }

        //14443卡数据读取
        private void Read()
        {

                    //寻卡
                    try
                    {
                        TB_KH.Clear();
                        TB_Name.Clear();
                        TB_Money.Clear();
                        TB_YU.Clear();
                        cardID = ISO14443_Tag.ReadTag();
                        TB_KH.Text = cardID;
                        ISO14443_Tag.Is_Find = true;

                        //充值与制卡界面
                        ChargeAndBusiness CAB = new ChargeAndBusiness(cardID);
                        TP_CZ.Controls.Clear();
                        TP_CZ.Controls.Add(CAB);
                        CAB.myrefresh += new ChargeAndBusiness.refresh(refresh);
                        CAB.mresh += new ChargeAndBusiness.fresh(fresh);



                        //选卡
                        if (ISO14443_Tag.TagSelect(TB_KH.Text) == true)
                        {
                            ISO14443_Tag.Is_Select = true;

                            //验证

                                if (ISO14443_Tag.KeyA("4", "AAAAAAAAAAAA", TB_KH.Text) == "")
                                {

                                    //读数
                                   
                                        if (ISO14443_Tag.ReadData("4") != "")
                                        {
                                            if (ISO14443_Tag.ReadData("5") != "")
                                            {




                                                    //用户名
                                                    TB_Name.Clear();
                                                    string str = ISO14443_Tag.ReadData("4");
                                                    str = str.TrimStart('0');
                                                    TB_Name.Text = Carry.HexToChs(str);
                                                    //金额
                                                    TB_Money.Clear();
                                                    usr = userbll.SearchUserID(cardID);
                                                    cardID = usr.UserName;
                                                    TB_Money.Text = Convert.ToString(usr.UserMoney);
                                                         

                                            }


                                        }

                                }




                        }



                    }
                    catch (Exception er)
                    {
                        MessageBox.Show(er.Message);
                    }


                

              
 
        }

        //支付
        private void Btn_Q_Click(object sender, EventArgs e)
        {
            float mo, x;
            mo = Convert.ToSingle(TB_Money.Text.Trim());
            x = Convert.ToSingle(TB_X.Text.Trim());
            if (mo - x >= 0)
            {
                TB_YU.Text = Convert.ToString(mo - x);
                usr.UserName=TB_KH.Text.Trim();
                usr.UserMoney=float.Parse(TB_YU.Text.Trim());
                userbll.UserByID(usr);
                TB_X.Clear();
                TB_Money.Clear();
                MessageBox.Show("支付成功");
            }
            else
            {
                MessageBox.Show("余额不足，请充值!");
            }
        }

        //刷新金额
        private void refresh()
        {
            TB_Money.Clear();
            usr = userbll.SearchUserID(cardID);
            cardID = usr.UserName;
            TB_Money.Text = Convert.ToString(usr.UserMoney);
        }

        //更新用户信息
        private void fresh()
        {
            TB_Name.Clear();
            TB_Money.Clear();
            usr = userbll.SearchUserID(cardID);
            cardID = usr.UserName;
            TB_Money.Text = Convert.ToString(usr.UserMoney);
            string str = ISO14443_Tag.ReadData("4");
            str = str.TrimStart('0');
            TB_Name.Text = Carry.HexToChs(str);
        }


    }
}
