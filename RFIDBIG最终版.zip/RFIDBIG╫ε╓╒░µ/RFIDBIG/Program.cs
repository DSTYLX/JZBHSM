﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RFIDBIG
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //获取应用程序集的基目录
            string dataDir = AppDomain.CurrentDomain.BaseDirectory;
            if (dataDir.EndsWith("\\bin\\Debug\\") || dataDir.EndsWith("\\bin\\Release\\"))
            {
                //获取基目录的上一级目录全路径
                dataDir = System.IO.Directory.GetParent(dataDir).Parent.Parent.FullName;
                //设置当前应用程序集的“DataDirectory”为dataDir的值，DataDirectory是表示数据库路径的替换字符串
                AppDomain.CurrentDomain.SetData("DataDirectory", dataDir);
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
