﻿namespace RFIDBIG
{
    partial class XuiGai
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.Btn_Open = new System.Windows.Forms.Button();
            this.TB_RK_Baud = new System.Windows.Forms.TextBox();
            this.CB_RK = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TB_Name = new System.Windows.Forms.TextBox();
            this.TB_Money = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Btn_Right = new System.Windows.Forms.Button();
            this.TB_Bian = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.Btn_Open);
            this.groupBox4.Controls.Add(this.TB_RK_Baud);
            this.groupBox4.Controls.Add(this.CB_RK);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(338, 118);
            this.groupBox4.TabIndex = 17;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "入库串口";
            // 
            // Btn_Open
            // 
            this.Btn_Open.Location = new System.Drawing.Point(220, 45);
            this.Btn_Open.Name = "Btn_Open";
            this.Btn_Open.Size = new System.Drawing.Size(75, 23);
            this.Btn_Open.TabIndex = 4;
            this.Btn_Open.Text = "打开串口";
            this.Btn_Open.UseVisualStyleBackColor = true;
            this.Btn_Open.Click += new System.EventHandler(this.Btn_Open_Click);
            // 
            // TB_RK_Baud
            // 
            this.TB_RK_Baud.Location = new System.Drawing.Point(65, 69);
            this.TB_RK_Baud.Name = "TB_RK_Baud";
            this.TB_RK_Baud.Size = new System.Drawing.Size(121, 21);
            this.TB_RK_Baud.TabIndex = 3;
            // 
            // CB_RK
            // 
            this.CB_RK.FormattingEnabled = true;
            this.CB_RK.Location = new System.Drawing.Point(65, 32);
            this.CB_RK.Name = "CB_RK";
            this.CB_RK.Size = new System.Drawing.Size(121, 20);
            this.CB_RK.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = "波特率：";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "串口号：";
            // 
            // TB_Name
            // 
            this.TB_Name.Location = new System.Drawing.Point(68, 171);
            this.TB_Name.Name = "TB_Name";
            this.TB_Name.Size = new System.Drawing.Size(100, 21);
            this.TB_Name.TabIndex = 22;
            // 
            // TB_Money
            // 
            this.TB_Money.Location = new System.Drawing.Point(68, 208);
            this.TB_Money.Name = "TB_Money";
            this.TB_Money.Size = new System.Drawing.Size(100, 21);
            this.TB_Money.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 20;
            this.label3.Text = "金额：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 19;
            this.label2.Text = "名称：";
            // 
            // Btn_Right
            // 
            this.Btn_Right.Location = new System.Drawing.Point(223, 174);
            this.Btn_Right.Name = "Btn_Right";
            this.Btn_Right.Size = new System.Drawing.Size(75, 23);
            this.Btn_Right.TabIndex = 18;
            this.Btn_Right.Text = "确定";
            this.Btn_Right.UseVisualStyleBackColor = true;
            this.Btn_Right.Click += new System.EventHandler(this.Btn_Right_Click);
            // 
            // TB_Bian
            // 
            this.TB_Bian.Location = new System.Drawing.Point(68, 134);
            this.TB_Bian.Name = "TB_Bian";
            this.TB_Bian.Size = new System.Drawing.Size(100, 21);
            this.TB_Bian.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 137);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 23;
            this.label1.Text = "编号：";
            // 
            // XuiGai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.TB_Bian);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_Name);
            this.Controls.Add(this.TB_Money);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Btn_Right);
            this.Controls.Add(this.groupBox4);
            this.Name = "XuiGai";
            this.Size = new System.Drawing.Size(354, 268);
            this.Load += new System.EventHandler(this.XuiGai_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button Btn_Open;
        private System.Windows.Forms.TextBox TB_RK_Baud;
        private System.Windows.Forms.ComboBox CB_RK;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TB_Name;
        private System.Windows.Forms.TextBox TB_Money;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Btn_Right;
        private System.Windows.Forms.TextBox TB_Bian;
        private System.Windows.Forms.Label label1;
    }
}
