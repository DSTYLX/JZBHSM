﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IES_ISO14443_Share;
using Model;
using DAL;
using BLL;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace RFIDBIG
{
    public partial class ChargeAndBusiness : UserControl
    {
        UserBLL userbll = new UserBLL();
        List<User> users = new List<User>();
        User usr = new User();
        public delegate void GetCard(string[] strs);
        public string CardID;
        public delegate void refresh();
        public event refresh myrefresh;

        public delegate void fresh();
        public event fresh mresh;

        public ChargeAndBusiness()
        {
            InitializeComponent();
        }

        public ChargeAndBusiness(string str)
        {
            InitializeComponent();
            CardID = str;
        }

        //制卡
        private void btnStartCreateCard_Click(object sender, EventArgs e)
        {
            string str;
            string[] Card = new string[8];
            int CardID = Convert.ToInt32("1") * 4 + 3;
            str = CardID.ToString();
            try
            {
                if (ISO14443_Tag.KeyB("4", "FFFFFFFFFFFF", txtCardID.Text.Trim()) == "")
                {
                    if (ISO14443_Tag.IntPurse("5") == "")
                    {
                        if (ISO14443_Tag.IncDec("5", txtAmount.Text.Trim() + "00", true) == "")
                        {
                            if (ISO14443_Tag.WriteData("4", Carry.ChsToHex(TB_Name.Text)) == "")
                            {
                                if (ISO14443_Tag.WriteKey("AAAAAAAAAAAA", "BBBBBBBBBBBB", "08778F69", str) == "")
                                {

                                    usr.UserName=txtCardID.Text.Trim();
                                    usr.UserMoney = float.Parse(txtAmount.Text.Trim());
                                    userbll.ADDUser(usr);
                                    MessageBox.Show("电子钱包制卡成功!");

                                    mresh();
                                    

                                
                                
                                }
                                else
                                {
                                    MessageBox.Show("电子钱包制卡失败!");
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("金额初始化失败!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("电子钱包初始化失败!");
                    }
                }
                else
                {
                    MessageBox.Show("密钥B验证失败!");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

        private void ChargeAndBusiness_Load(object sender, EventArgs e)
        {
            txtCardID.Clear();
            txtCardID.Text = CardID;
            TB.Clear();
            TB_M.Text = txtCardID.Text.Trim();
            usr = userbll.SearchUserID(TB_M.Text.Trim());
            TB_M.Text = usr.UserName;
            TB.Text = Convert.ToString(usr.UserMoney);
            txtCardID.Clear();
            txtCardID.Text = CardID;
            

        }

        //充值
        private void btnACharge_Click(object sender, EventArgs e)
        {
            try
            {
                if (ISO14443_Tag.KeyB("7", "BBBBBBBBBBBB", CardID) == "")
                {

                    if (ISO14443_Tag.IncDec("5", txtAChargeAmount.Text.Trim() +"00", true) == "")
                    {
                        
                        
                        //写入数据库
                        float a = float.Parse(TB.Text.Trim());
                        float b = float.Parse(txtAChargeAmount.Text.Trim());
                        float c = a + b;
                        usr.UserName = txtCardID.Text.Trim();
                        usr.UserMoney = c;
                        userbll.UserByID(usr);
                        txtAChargeAmount.Clear();
                        TB.Clear();

                        usr = userbll.SearchUserID(txtCardID.Text.Trim());
                        txtCardID.Text = usr.UserName;
                        TB.Text = Convert.ToString(usr.UserMoney);

                        myrefresh();

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


                
            
                
        }

        //正则效验
        private void txtAChargeAmount_TextChanged(object sender, EventArgs e)
        {
            {
                if (Regex.IsMatch(txtAChargeAmount.Text.Trim(), @"^[0-9]+(\.[0-9]{1,2})?$|^[0-9]+\.$"))
                {
                    txtAChargeAmount.Text = (Convert.ToSingle(txtAChargeAmount.Text.Trim())).ToString();
                }
                else
                {
                    txtAChargeAmount.SelectionStart = 0;
                    txtAChargeAmount.SelectionLength = txtAChargeAmount.TextLength;
                    txtAChargeAmount.Focus();
                }

            }
        }
        



    }
}
