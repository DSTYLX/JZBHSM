﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using Model;
using BLL;
using System.Data.SqlClient;
using System.Threading;
using System.IO.Ports;

namespace RFIDBIG
{
    public partial class TianJia : UserControl
    {
        UserBLL userbll = new UserBLL();
        User usr = new User();
        public string str;
        private Thread thread;
        bool IsOpen;
        SerialPort SerialPort;
        byte[] rcvdata = new byte[5];
        int ID;

        public delegate void refresh();
        public event refresh myrefresh;

        

        public TianJia()
        {
            InitializeComponent();
        }

        public TianJia(string str)
        {
            InitializeComponent();
            this.str = str;
        }

        private void Btn_Right_Click(object sender, EventArgs e)
        {
            //写入数据库
            int[] a = new int[LB_BH.Items.Count];
            for (int i = 0; i < LB_BH.Items.Count; i++)
            {
                usr.PortID = Convert.ToInt32(LB_BH.Items[i]);
                usr.Name = TB_Name.Text.Trim();
                usr.Money = float.Parse(TB_Money.Text.Trim());
                userbll.AddUser(usr);


            }
            LB_BH.Items.Clear();
            TB_Name.Clear();
            TB_Money.Clear();

            MessageBox.Show("入库成功!");

            myrefresh();

            SerialPort.Close();
            Btn_Open.Text = "打开串口";
            IsOpen = false;


        }

        private void TianJia_Load(object sender, EventArgs e)
        {
           
            Control.CheckForIllegalCrossThreadCalls = false;
            string[] portID = SerialPort.GetPortNames();
            if (portID.Length < 0)
            {
                MessageBox.Show("没有找到系统窗口！");
            }
            else
            {
                CB_RK.Items.AddRange(portID);
                CB_RK.SelectedIndex = 0;
            }
            TB_RK_Baud.Text = "9600";
        }

        private void Btn_Open_Click(object sender, EventArgs e)
        {
            if (Btn_Open.Text == "打开串口")
            {
                if (CB_RK.SelectedIndex < 0)
                {
                    MessageBox.Show("请选择串口");
                }
                else
                {
                    try
                    {
                        SerialPort = new SerialPort(CB_RK.Text);
                        SerialPort.DataBits = 8;
                        SerialPort.StopBits = StopBits.One;
                        SerialPort.Parity = Parity.None;
                        SerialPort.Open();
                        if (SerialPort.IsOpen)
                        {
                            Btn_Open.Text = "关闭串口";
                            IsOpen = true;
                            MessageBox.Show("串口打开成功");
                            thread = new Thread(ReceiveData);
                            thread.IsBackground = true;
                            thread.Start();




                        }
                    }
                    catch
                    {
                        MessageBox.Show("串口打开失败");
                    }

                }
            }
            else
            {
                if (IsOpen)
                {
                    SerialPort.Close();
                    Btn_Open.Text = "打开串口";
                    IsOpen = false;
                    MessageBox.Show("串口关闭");
                }
                else
                {
                    MessageBox.Show("串口已关闭");
                }
            }
        }

        private void ReceiveData()
        {


            if (IsOpen)
            {
                IsOpen = true;
                while (IsOpen)
                {

                    try
                    {


                        if (SerialPort.BytesToRead > 4)
                        {
                            int count = SerialPort.Read(rcvdata, 0, 5);

                            if (count == 5)
                            {
                                string time = System.DateTime.Now.ToLongTimeString();
                                string str = " ";
                                foreach (byte value in rcvdata)
                                {
                                    str += string.Format("{0:X2} ", value);
                                }

                                string strWGData = string.Format("{0:D3}{1:D5}", rcvdata[1], rcvdata[2] * 256 + rcvdata[3]);
                                ID = Convert.ToInt32(strWGData);
                                LB_BH.Items.Add(Convert.ToString(ID));


                                Int32 sum = rcvdata[0] + rcvdata[1] + rcvdata[2] + rcvdata[3] + rcvdata[4];
                                if (sum == 0)
                                {
                                    MessageBox.Show("接收到的数据全是0，请检查设备连接!");
                                }
                                else
                                {
                                    Thread.Sleep(20);
                                }
                            }
                            else
                            {
                                Thread.Sleep(20);
                            }



                        }
                        else
                        {
                            Thread.Sleep(20);
                        }
                    }
                    catch
                    {
                        IsOpen = false;
                        //MessageBox.Show("数据接收错误");
                        break;
                    }

                }
            }
            else
            {
                IsOpen = false;

            }
        }
    }
}
