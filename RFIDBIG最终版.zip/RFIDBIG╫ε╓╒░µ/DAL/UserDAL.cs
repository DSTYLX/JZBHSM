﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Data.SqlClient;


namespace DAL
{
   public  class UserDAL
    {
        SqlConnection con;//使用SqlConnection对象连接数据库
        SqlCommand cmd; //使用SqlCommand对象，负责SQL语句的执行和存储过程的调用
        SqlDataReader rd;//对SQL语句或存储过程执行后的结果进行操作，返回的是一个“流”，可以直接一行一行的读取数据集（rd.Read()，读到一行数据则返回true）

        //添加商品数据
        public int AddUser(User usr)
        {
            int row;
            try
            {
                con = DBConnection.CreateDBConnection();
                string sql = "insert into Cash (PortID,Name,Money) values(@PortID,@Name,@Money)";
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@PortID", usr.PortID);
                cmd.Parameters.AddWithValue("@Name", usr.Name);
                cmd.Parameters.AddWithValue("@Money", usr.Money);
                row = cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return row;
        }

       //添加用户数据
        public int ADDUser(User usr)
        {
            int row;
            try
            {
                con = DBConnection.CreateDBConnection();
                string sql = "insert into T_User (UserName,UserMoney) values(@UserName,@UserMoney)";
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@UserName", usr.UserName);
                cmd.Parameters.AddWithValue("@UserMoney", usr.UserMoney);
                row = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return row;
        }

        //查找所有商品信息
        public List<User> SelectAllUsers()
        {
            List<User> users = new List<User>();
            try
            {
                con = DBConnection.CreateDBConnection();
                string sql = "select * from Cash";
                cmd = new SqlCommand(sql, con);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    User usr = new User();
                    usr.PortID = rd.GetInt32(0);
                    usr.Name = rd.GetString(1);
                    usr.Money = Convert.ToSingle(rd.GetValue(2));
                    users.Add(usr);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return users;

        }

        //按ID查找商品
        public User SearchPortID(int PortID)
        {
            User usr = new User();
            try
            {
                con = DBConnection.CreateDBConnection();
                string sql = "select * from Cash where PortID like '%" + PortID + "%'";
                cmd = new SqlCommand(sql, con);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {

                    usr.PortID = rd.GetInt32(0);
                    usr.Name = rd.GetString(1);
                    usr.Money = Convert.ToSingle(rd.GetValue(2));
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return usr;
        }

       //按ID查找用户
        public User SearchUserID(string UserName)
        {
            User usr = new User();
            try
            {
                con = DBConnection.CreateDBConnection();
                string sql = "select * from T_User where UserName like '%" + UserName + "%'";
                cmd = new SqlCommand(sql, con);
                rd = cmd.ExecuteReader();
                while (rd.Read())
                {

                    
                    usr.UserName = rd.GetString(0);
                    usr.UserMoney = Convert.ToSingle(rd.GetValue(1));
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return usr;
        }


        //按ID删除
        public int DeletePortID(int ID)
        {
            int row;
            try
            {
                con = DBConnection.CreateDBConnection();
                string sql = "delete from Cash where PortID=" + ID;
                cmd = new SqlCommand(sql, con);
                row = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return row;
        }

       //按ID更新商品信息
        public int UpdateByID(User usr)
        {
            int row;
            try
            {
                con = DBConnection.CreateDBConnection();
                string sql = "update Cash set Name=@Name,Money=@Money where PortID=@PortID";
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@PortID", usr.PortID);
                cmd.Parameters.AddWithValue("@Name", usr.Name);
                cmd.Parameters.AddWithValue("@Money", usr.Money);

                row = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return row;
        }

       //按ID更新用户信息
        public int UserByID(User usr)
        {
            int row;
            try
            {
                con = DBConnection.CreateDBConnection();
                string sql = "update T_User set UserMoney=@UserMoney where UserName=@UserName";
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@UserName", usr.UserName);
                cmd.Parameters.AddWithValue("@UserMoney", usr.UserMoney);

                row = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return row;
        }

    }
}
