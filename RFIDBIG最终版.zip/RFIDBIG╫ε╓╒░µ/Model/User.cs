﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class User
    {
        #region
        private int _PortID;
        private string _Name;
        private float _Money;
        private string _UserName;
        private float _UserMoney;
        #endregion

        #region 属性
        public int PortID
        {
            get { return _PortID; }
            set { _PortID = value; }
        }

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public float Money
        {
            get { return _Money; }
            set { _Money = value; }
        }

        public string UserName
        { get; set; }

        public float UserMoney
        { get; set; }
        #endregion
    }
}
