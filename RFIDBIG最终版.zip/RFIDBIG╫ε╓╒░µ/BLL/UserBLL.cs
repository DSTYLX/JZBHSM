﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using DAL;

namespace BLL
{
    public class UserBLL
    {
        UserDAL userdal = new UserDAL();
        public int AddUser(User usr)
        {
            int row = userdal.AddUser(usr);
            return row;
        }

        public List<User> SearchAllUsers()
        {
            List<User> users = userdal.SelectAllUsers();
            return users;
        }

        public User SearchPortID(int PortID)
        {
            User usr = userdal.SearchPortID(PortID);
            return usr;
        }

        public int DeletePortID(int ID)
        {
            int row = userdal.DeletePortID(ID);
            return row;
        }

        public User SearchUserID(string UserName)
        {
            User usr = userdal.SearchUserID(UserName);
            return usr;
        }

        public int ADDUser(User usr)
        {
            int row = userdal.ADDUser(usr);
            return row;
        }

        public int UpdateByID(User usr)
        {
            int row = userdal.UpdateByID(usr);
            return row;
        }

        public int UserByID(User usr)
        {
            int row = userdal.UserByID(usr);
            return row;
        }

    }
}
